<!-- Header Section Starts -->

<!-- Favicon -->
<link rel="shortcut icon" href="./favicon.ico" />

<!-- Font -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap" rel="stylesheet" />

<!-- CSS Implementing Plugins -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/vendor.min.css" />
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/vendor/icon-set/style.css" />

<!-- CSS Front Template -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/theme.min.css?v=1.0" />

<!-- Custom CSS Template -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/custom.css?v=1.0" />

<!-- End Header Section -->