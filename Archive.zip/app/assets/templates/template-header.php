
<!-- Header Section -->
<!-- favicon -->
<link rel="shortcut icon" href="<?= $base_URI; ?>/app/assets/img/favicon.ico" type="image/x-icon" />
<!-- Bootstrap 4.5 -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/bootstrap.min.css" type="text/css" />
<!-- animate -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/animate.css" type="text/css" />
<!-- Swiper -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/swiper.min.css" />
<!-- aos -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/aos.css" type="text/css" />
<!-- icons -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/icons.css" type="text/css" />
<!-- Main css -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/main.css" type="text/css" />
<!-- Normalize CSS -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/normalize.css" type="text/css" />
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
<!-- Microtip CSS -->
<link rel="stylesheet" href="https://unpkg.com/microtip/microtip.css" />
<!-- Custom CSS -->
<link rel="stylesheet" href="<?= $base_URI; ?>/app/assets/css/custom.css?v=1.0.0" type="text/css" />
<!-- js for Brwoser -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- Global site tag (gtag.js) - Google Ads: 971083070 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-971083070"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag('js', new Date());

gtag('config', 'AW-971083070');
</script>
<!-- Event snippet for Website sale conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
function gtag_report_conversion(url) {
    var callback = function () {
    if (typeof (url) != 'undefined') {
        window.location = url;
    }
    };
    gtag('event', 'conversion', {
    'send_to': 'AW-971083070/7bFICNXzudkBEL6ahs8D',
    'transaction_id': '',
    'event_callback': callback
    });
    return false;
}
</script>

