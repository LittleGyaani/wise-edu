<?php
//Code is Property
echo "It's all quite here.";